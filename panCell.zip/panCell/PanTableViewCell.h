//
//  PanTableViewCell.h
//  UITableView-侧滑
//
//  Created by juliu on 16/12/27.
//  Copyright © 2016年 juliu. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, PanCellAnimatedStyle) {
    PanCellAnimatedStyleNone,    // 无同步动画效果,类似系统的效果
    PanCellAnimatedStyleDefault, // 默认 进度滑动
    PanCellAnimatedStyleOverlap, // 重叠渐变出现
    PanCellAnimatedStyleParallax // 不完全同步滚动效果, 类似系统导航栏滑动返回效果
};

@class PanCellButton;
@class PanTableViewCell;

@protocol PanTableViewCellDelegate <NSObject>

@required

/**
 *  左滑cell时显示的button 返回nil表示不创建左边菜单
 *
 *  @param tableView cell所在的tableView
 *  @param indexPath cell的位置
 */
- (NSArray<PanCellButton *> *)panTableViewCell:(PanTableViewCell *)cell tableView:(UITableView *)tableView leftPanCellButtonsAtIndexPath:(NSIndexPath *)indexPath;

/**
 *  右滑cell时显示的button 返回nil表示不创建右边菜单
 *
 *  @param tableView cell所在的tableView
 *  @param indexPath cell的位置
 */
- (NSArray<PanCellButton *> *)panTableViewCell:(PanTableViewCell *)cell tableView:(UITableView *)tableView rightPanCellButtonsAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface PanTableViewCell : UITableViewCell

@property (nonatomic, weak) id<PanTableViewCellDelegate> delegate;

@property (nonatomic, assign) PanCellAnimatedStyle animatedStyle;

/** 是否在滑动时关闭其他已经打开的滑动菜单 默认YES */
@property (assign, nonatomic, getter=isCloseOtherPanCellMenuViewWhenOpen) BOOL closeOtherPanCellMenuViewWhenOpen;
/** 松开手时决定是否取消还是完成返回的临界比例 (0,1)  -- 滑动了多少距离  默认为0.5 */
@property (assign, nonatomic) CGFloat threholdPercent;
/** 松开手时决定是否取消还是完成返回的临界速度 >=0 默认为200 */
@property (assign, nonatomic) CGFloat threholdSpeed;
/** 动画时间 默认为0.25s */
@property (assign, nonatomic) CGFloat animatedDuration;
/** 添加的覆盖view的背景色 默认为白色 */
@property (strong, nonatomic) UIColor *overlayerBackgroundColor;

- (void)animatedCloseRight;

@end
