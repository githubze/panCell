//
//  PanCellButton.m
//  UITableView-侧滑
//
//  Created by juliu on 16/12/27.
//  Copyright © 2016年 juliu. All rights reserved.
//

#import "PanCellButton.h"
#import "UIColor+Tool.h"

#define Margin  5 // 图片与文字的间距
#define Image_Width 50  // 图片高度、高度
#define Width   80  // 自身宽度、高度


#define Title_Color 0x666666

@interface PanCellButton ()

@property (nonatomic, copy) PanCellButtonCallback callback;

@end

@implementation PanCellButton

- (instancetype)initWithTitle:(NSString *)title image:(UIImage *)image onClickCallback:(PanCellButtonCallback)callback {
    if (self = [super init]) {
        self.callback = callback;
        [self addTarget:self action:@selector(panCellButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self setTitle:title forState:UIControlStateNormal];
        [self setImage:image forState:UIControlStateNormal];
        [self setTitleColor:[UIColor colorWithRGB:Title_Color] forState:UIControlStateNormal];
        self.backgroundColor = [UIColor whiteColor];
        
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        
        // 因为该初始化接口是提供给使用者的，而按钮的父控件不应该被使用者使用，其宽度需要按钮的宽度设置。所以这时候就设置了frame。
        // 注意只有宽有效。其frame会在父控件侧滑菜单(PanCellView)中调整
        CGSize textSize = [title boundingRectWithSize:CGSizeMake(MAXFLOAT, 200.f) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: self.titleLabel.font, NSForegroundColorAttributeName: self.titleLabel.textColor } context:nil].size;
//        CGFloat btnWidth = MAX(image.size.width + Margin * 2, textSize.width + Margin * 2);
        
        CGFloat btnWidth = 50;
        
        self.frame = CGRectMake(0.f, 0.f, btnWidth, image.size.height + textSize.height + Margin * 3);
    }
    return self;
}

- (void)panCellButtonClick:(PanCellButton *)button {
    if (self.callback) {
        self.callback(button);
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    // 如果设置了图片, 让图片在上, 文字在下显示
    if (self.imageView.image) {
        CGFloat selfHeight = self.bounds.size.height;
        CGFloat selfWidth = self.bounds.size.width;
        CGSize imageSize = self.imageView.image.size;
        CGFloat margin = (selfHeight - imageSize.height - self.titleLabel.bounds.size.height - Margin)/2;
        
        self.imageView.frame = CGRectMake((selfWidth - imageSize.width)/2, margin, imageSize.width, imageSize.height);
        self.titleLabel.frame = CGRectMake(0, CGRectGetMaxY(self.imageView.frame) + margin, selfWidth, self.titleLabel.frame.size.height);
    }
}

@end
