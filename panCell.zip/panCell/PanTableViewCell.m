//
//  PanTableViewCell.m
//  UITableView-侧滑
//
//  Created by juliu on 16/12/27.
//  Copyright © 2016年 juliu. All rights reserved.
//

#import "PanTableViewCell.h"
#import "PanCellMenuView.h"
#import "UIView+Tool.h"

// 滑动操作的类型
typedef NS_ENUM(NSUInteger, PanCellOperation) {
    PanCellOperationNone,
    PanCellOperationOpenLeft,
    PanCellOperationCloseLeft,
    PanCellOperationOpenRight,
    PanCellOperationCloseRight
};

@interface PanTableViewCell () <UIGestureRecognizerDelegate>

// 截图
@property (strong, nonatomic) UIView *snapView;
// 所有添加的subviews的容器, 滑动时覆盖在cell上
@property (nonatomic, strong) UIView *overlayerContentView;
// 右边的滑动菜单
@property (nonatomic, strong) PanCellMenuView *rightView;
// 左边的滑动菜单
@property (nonatomic, strong) PanCellMenuView *leftView;

// cell所在的tableView
@property (nonatomic, weak) UITableView *tableView;
// cell的选中style 便于复原
@property (nonatomic, assign) UITableViewCellSelectionStyle reallySelectionStyle;

//手势
@property (strong, nonatomic) UIPanGestureRecognizer *panGesture;
@property (strong, nonatomic) UITapGestureRecognizer *tapGesture;

@property (nonatomic, assign) PanCellOperation panCellOperation;
// 用于不同动画类型的时候设置相应的比例
@property (nonatomic, assign) CGFloat animatedTypePercent;

// 记录手势开始的时候 overlayerContentView 的x
@property (nonatomic, assign) CGFloat beginContentViewX;
// 记录手势开始的时候 snapView 的x
@property (nonatomic, assign) CGFloat beginSnapViewX;
// 记录手势开始的时候手指的位置, 当手指松开时判断滑动了多远,是否完成滑动
@property (nonatomic, assign) CGFloat beginX;

@end


@implementation PanTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self commonInit];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self commonInit];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self commonInit];
    }
    return self;
}

- (void)commonInit {
    self.panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGestureCallback:)];
    self.panGesture.delegate = self;
    [self addGestureRecognizer:self.panGesture];
    
    _closeOtherPanCellMenuViewWhenOpen = YES;
    _animatedStyle = PanCellAnimatedStyleDefault;
    _overlayerBackgroundColor = [UIColor whiteColor];
    _threholdPercent = 0.5;
    _animatedDuration = 0.25;
    _threholdSpeed = 200.f;
    
}

- (void)willMoveToSuperview:(UIView *)newSuperview {
    [super willMoveToSuperview:newSuperview];
    _reallySelectionStyle = self.selectionStyle;
}

- (void)panGestureCallback:(UIPanGestureRecognizer *)panGesture {
    CGFloat locationX = [panGesture locationInView:self].x;
    CGFloat transitionX = [panGesture translationInView:self].x;
    CGFloat velocityX = [panGesture velocityInView:self].x;
    
    switch (panGesture.state) {
        case UIGestureRecognizerStateBegan: {
            self.selectionStyle = UITableViewCellSelectionStyleNone;
            
#warning 下面一句都解决不了滑动时，让cell变白的效果。怎么办呢？
            self.contentView.backgroundColor = [UIColor whiteColor];
            
            // 设置左右侧滑菜单和截图
            [self setupCellPanViewWithPanVelocityX:velocityX];
            self.beginX = locationX;
            self.beginSnapViewX = self.snapView.x;
            self.beginContentViewX = self.overlayerContentView.x;
            self.panCellOperation = PanCellOperationNone;
        }
            break;
        case UIGestureRecognizerStateChanged: {
            // 设置左右侧滑菜单和截图
            CGFloat tempSnapViewX = self.beginSnapViewX;
            tempSnapViewX += transitionX;
            self.snapView.x = tempSnapViewX;

            // 关闭右边 或 打开左边
            if (transitionX > 0) {
                // 如果刚开始右边的菜单是打开的，那么正在 关闭右边的菜单
                if (self.rightView && self.beginSnapViewX == -self.rightView.width) {
                    self.panCellOperation = PanCellOperationCloseRight;
                    
                    [self hideAndShowMenuViewWithShowleft:NO];
                    
                    // 正在关闭右边
                    if (transitionX < self.rightView.width) {
                        CGFloat tempX = self.beginContentViewX;
                        tempX += transitionX * self.animatedTypePercent;
                        self.overlayerContentView.x = tempX;
                    } else {
                        // 手指向右移动的距离 超过 右边菜单的宽度,说明右边菜单已经完全关闭
                        // 此时正要 打开左边菜单。
                        // 重新设置初始值，改变判断条件
                        [panGesture setTranslation:CGPointZero inView:self];
                        
                        self.beginContentViewX = -self.leftView.width * self.animatedTypePercent;
                        self.beginX = locationX;
                        self.beginSnapViewX = 0;
                        self.overlayerContentView.x = -self.leftView.width * self.animatedTypePercent;
                    }
                    [self animatePanCellButtonsWithPercent:transitionX/self.rightView.width];
                } else {
                    // 走下来，表示开始时，右边没打开。
                    // 即表示开始时，左右两边都没打开，或左边打开。
                    // 状态： 正在打开左边 或 左边已打开并拉扯着往右边走
                    self.panCellOperation = PanCellOperationOpenLeft;
                    if (!self.leftView) return;
                    [self hideAndShowMenuViewWithShowleft:YES];
                    
                    // 左右两边菜单都没打开的情况下右滑
                    if (self.beginContentViewX != 0) {
                        if (transitionX >= self.leftView.width) {
                            self.overlayerContentView.x = 0.f; //固定overlayerContentView
                            transitionX = self.leftView.width;
                        } else {
                            // 滚动overLayerContentView
                            CGFloat tempX = self.beginContentViewX;
                            tempX += transitionX * self.animatedTypePercent;
                            self.overlayerContentView.x = tempX;
                        }
                    } else {
                        // 刚开始左边菜单打开的情况下右滑 固定 transitionX
                        transitionX = self.leftView.width;
                    }
                    [self animatePanCellButtonsWithPercent:transitionX/self.leftView.width];
                }
            }
            
            // 关闭左边 或 打开右边
            if (transitionX < 0) {
                // 如果刚开始左边是打开的，表示正在 关闭左边
                if (self.leftView && _beginSnapViewX == self.leftView.width) {
                    self.panCellOperation = PanCellOperationCloseLeft;
                    [self hideAndShowMenuViewWithShowleft:YES];
                    
                    if (transitionX > -self.leftView.width) {
                        // 正在关闭左边
                        CGFloat tempX = _beginContentViewX;
                        tempX += transitionX*self.animatedTypePercent;
                        self.overlayerContentView.x = tempX;
                    } else {
                        // 左边关闭完成，此时正要打开右边
                        [panGesture setTranslation:CGPointZero inView:self];
                        self.beginContentViewX = -self.leftView.width * self.animatedTypePercent;
                        self.beginX = locationX;
                        self.beginSnapViewX = 0;
                        transitionX = -self.leftView.width;
                        self.overlayerContentView.x = -self.leftView.width * self.animatedTypePercent;
                    }
                    [self animatePanCellButtonsWithPercent:-transitionX/self.leftView.width];
                } else {
                    // 开始左边没打开，表示正在 打开右边
                    self.panCellOperation = PanCellOperationOpenRight;
                    if (!self.rightView) {
                        return;
                    }
                    [self hideAndShowMenuViewWithShowleft:NO];
                    
                    // 右边完全打开的情况下右滑
                    if (self.beginSnapViewX == -self.rightView.width) {
                        transitionX = -self.rightView.width;
                    } else {
                        // 正在打开右边
                        CGFloat tempX = self.beginContentViewX;
                        tempX += transitionX * self.animatedTypePercent;
                        self.overlayerContentView.x = tempX;
                    }
                }
                [self animatePanCellButtonsWithPercent:-transitionX/self.rightView.width];
            }
        }
            break;
        case UIGestureRecognizerStateEnded: {
            CGFloat velocityX = [panGesture velocityInView:self].x;
            [self handleFinishOrCancelWithVelocityX:velocityX andLocationX:locationX];
        }
            break;
            
        default:
            break;
    }
}

- (void)handleFinishOrCancelWithVelocityX:(CGFloat)velocityX andLocationX:(CGFloat)locationX {
    
    if (self.panCellOperation == PanCellOperationOpenLeft) {
        if (fabs(self.beginX - locationX) > self.leftView.width * self.threholdPercent) {
            [self animatedOpenLeft];
        } else {
            //判断离开的速度
            if (fabs(velocityX) > self.threholdSpeed) {
                [self animatedOpenLeft];
            } else {
                [self animatedCloseLeft];
            }
        }
    } else if (self.panCellOperation == PanCellOperationCloseLeft) {
        if (fabs(self.beginX - locationX) > self.leftView.width * self.threholdPercent) {
            [self animatedCloseLeft];
        } else {
            if (fabs(velocityX) > _threholdSpeed) {
                [self animatedCloseLeft];
            } else {
                [self animatedOpenLeft];
            }
        }
    } else if (self.panCellOperation == PanCellOperationOpenRight) {
        if (fabs(self.beginX - locationX) > self.rightView.width * self.threholdPercent) {
            [self animatedOpenRight];
        } else {
            if (fabs(velocityX) > _threholdSpeed) {
                [self animatedOpenRight];
            } else {
                [self animatedCloseRight];
            }
        }
    } else if (self.panCellOperation == PanCellOperationCloseRight) {
        // 如果手指移动的距离 > 我们定义的百分比 说明应该执行动画关闭右边菜单
        if (fabs(self.beginX - locationX) > self.rightView.width * self.threholdPercent) {
            [self animatedCloseRight];
        } else {
            // 如果手指移动的距离较小, 就判断手指离开的速度是否大于我们定义的最小速度
            // 如果大于证明应该执行动画关闭右边菜单, 否则说明关闭右边失败, 重新打开 右边菜单
            if (fabs(velocityX) > _threholdSpeed) {
                [self animatedCloseRight];
            } else {
                [self animatedOpenRight];
            }
        }
    }
}

/**
 *  设置CellPanView。
 *
 *  @param velocityX 表示手指滑动的向量
 */
- (void)setupCellPanViewWithPanVelocityX:(CGFloat)velocityX {
    if (!self.overlayerContentView) {
        if (self.closeOtherPanCellMenuViewWhenOpen) {
            for (UITableViewCell *cell in [self.tableView visibleCells]) {
                if ([cell isKindOfClass:[PanTableViewCell class]]) {
                    PanTableViewCell *panCell = (PanTableViewCell *)cell;
                    if (panCell != nil) {
                        [panCell tapGestureCallback:nil];
                    }
                }
            }
        }
        
        NSArray<PanCellButton *> *leftBtns;
        if ([self.delegate respondsToSelector:@selector(panTableViewCell: tableView: leftPanCellButtonsAtIndexPath:)]) {
            leftBtns = [self.delegate panTableViewCell:self tableView:self.tableView leftPanCellButtonsAtIndexPath:[self.tableView indexPathForCell:self]];
        }
        
        NSArray<PanCellButton *> *rightBtns;
        if ([self.delegate respondsToSelector:@selector(panTableViewCell: tableView: rightPanCellButtonsAtIndexPath:)]) {
            rightBtns = [self.delegate panTableViewCell:self tableView:self.tableView rightPanCellButtonsAtIndexPath:[self.tableView indexPathForCell:self]];
        }
        
        if ((leftBtns.count==0 && velocityX>0) || (rightBtns.count==0 && velocityX<0)) {
            return;
        }
        
        // tableView添加tap手势，并开始监听tableView的pan手势状态。如果为begin，则进行close处理，在close处理时让tableview移除self.tapGesture。
        [self.tableView addGestureRecognizer:self.tapGesture];
        [self addTableViewObserver];
        
        // 初始化 overlayerContentView
        CGFloat overlayContentViewWidth = self.bounds.size.width;
        self.overlayerContentView = [[UIView alloc] initWithFrame:self.bounds];
        self.overlayerContentView.backgroundColor = self.overlayerBackgroundColor;
        
        if (!self.leftView) {
            if (leftBtns.count > 0) {
                self.leftView = [[PanCellMenuView alloc] initWithPanCellButtons:leftBtns height:self.bounds.size.height];
                self.leftView.x = 0.f;
                overlayContentViewWidth += (self.leftView.width * self.animatedTypePercent);
                [self.overlayerContentView addSubview:self.leftView];
            }
        }
        
        if (!self.rightView) {
            if (rightBtns.count) {
                self.rightView = [[PanCellMenuView alloc] initWithPanCellButtons:rightBtns height:self.bounds.size.height];
                overlayContentViewWidth += (self.rightView.width * self.animatedTypePercent);
                self.rightView.x = overlayContentViewWidth - self.rightView.width;
                [self.overlayerContentView addSubview:self.rightView];
            }
        }
        
        self.overlayerContentView.x = -self.leftView.width * self.animatedTypePercent;
        self.overlayerContentView.width = overlayContentViewWidth;
        [self.contentView addSubview:self.overlayerContentView];
        
        // 添加截图
        
        if (!self.snapView) {
            // 系统提供的方法 iOS7之后就不用我们自己来绘图实现截图的需求了
            self.snapView = [self snapshotViewAfterScreenUpdates:NO];
            self.snapView.frame = self.bounds;
            [self.contentView addSubview:self.snapView];
        }
    }
}

/**
 *  隐藏左边或者右边的swipeView
 *
 *  @param isShowLeft 是否需要显示左边的swipeView
 */
- (void)hideAndShowMenuViewWithShowleft:(BOOL)isShowLeft {
    if (isShowLeft) {
        self.leftView.hidden = NO;
        self.rightView.hidden = YES;
    }
    else {
        self.leftView.hidden = YES;
        self.rightView.hidden = NO;
    }
}

- (void)animatePanCellButtonsWithPercent:(CGFloat)percent {
    if (self.animatedStyle != PanCellAnimatedStyleOverlap) {
        return;
    }
    //    NSLog(@"%f", percent);
    CGFloat x=0;
    
    if (self.panCellOperation == PanCellOperationOpenLeft) {
        for (PanCellButton *panBtn in [self.leftView.subviews reverseObjectEnumerator]) {
            panBtn.x = (self.leftView.width - panBtn.width - x) * (1.0 - percent) + x;
            x += panBtn.width;
        }
    } else if (self.panCellOperation == PanCellOperationCloseLeft) {
        for (PanCellButton *panBtn in [self.leftView.subviews reverseObjectEnumerator]) {
            panBtn.x = (self.leftView.width - panBtn.width - x) * percent + x;
            x += panBtn.width;
        }
        
    } else if (self.panCellOperation == PanCellOperationOpenRight) {
        for (PanCellButton *panBtn in self.rightView.subviews) {
            panBtn.x = x * percent;
            x += panBtn.width;
        }
        
    } else if (self.panCellOperation == PanCellOperationCloseRight) {
        for (PanCellButton *panBtn in self.rightView.subviews) {
            panBtn.x = x * (1-percent);
            x += panBtn.width;
        }
    }
}

#pragma mark - 监听cell的tableView的pan手势状态

static char PanTableViewCellContext = '\0';
static NSString * const TableViewPanGesturePath = @"tableView.panGestureRecognizer.state";

- (void)addTableViewObserver {
    [self addObserver:self forKeyPath:TableViewPanGesturePath options:NSKeyValueObservingOptionInitial context:&PanTableViewCellContext];
}

- (void)removeTableViewObserver {
    if (self.overlayerContentView) {
        [self removeObserver:self forKeyPath:TableViewPanGesturePath];
    }
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    if (context == &PanTableViewCellContext && keyPath == TableViewPanGesturePath) {
        if (self.tableView.panGestureRecognizer.state == UIGestureRecognizerStateBegan) {
            // 相当于点击了tableView 关闭滑动菜单
            [self tapGestureCallback:nil];
        }
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)animatedOpenLeft {
    [UIView animateWithDuration:_animatedDuration animations:^{
        self.snapView.x = self.leftView.width;
        self.overlayerContentView.x = 0;
        if (self.animatedStyle == PanCellAnimatedStyleOverlap) {
            CGFloat x=0;
            for (PanCellButton *panBtn in [self.leftView.subviews reverseObjectEnumerator]) {
                panBtn.x = x;
                x += panBtn.width;
            }
        }
    } completion:nil];
}

- (void)animatedCloseLeft {
    [UIView animateWithDuration:_animatedDuration animations:^{
        self.snapView.x = 0;
        self.overlayerContentView.x = -self.leftView.width * self.animatedTypePercent;
        if (self.animatedStyle == PanCellAnimatedStyleOverlap) {
            for (PanCellButton *panBtn in [self.leftView.subviews reverseObjectEnumerator]) {
                panBtn.x = self.leftView.width - panBtn.width;
            }
        }
    } completion:^(BOOL finished) {
        [self resetInitialState];
    }];
}

- (void)animatedOpenRight {
    [UIView animateWithDuration:_animatedDuration animations:^{
        self.snapView.x = -self.rightView.width;
        self.overlayerContentView.x = -(self.leftView.width+self.rightView.width)*self.animatedTypePercent;
        if (self.animatedStyle == PanCellAnimatedStyleOverlap) {
            CGFloat x=0;
            for (PanCellButton *panBtn in self.rightView.subviews) {
                panBtn.x = x;
                x += panBtn.width;
            }
        }
    } completion:nil];
}

- (void)animatedCloseRight {
    [UIView animateWithDuration:_animatedDuration animations:^{
        self.snapView.x = 0;
        self.overlayerContentView.x = -self.leftView.width*self.animatedTypePercent;
        if (self.animatedStyle == PanCellAnimatedStyleOverlap) {
            for (PanCellButton *panBtn in self.rightView.subviews) {
                panBtn.x = 0;
            }
        }
    } completion:^(BOOL finished) {
        [self resetInitialState];
    }];
}

- (void)resetInitialState {
    // 移除kvo监听者
    [self removeTableViewObserver];
    // 移除tap手势
    [self.tableView removeGestureRecognizer:self.tapGesture];
    // 移除添加的view
    self.tapGesture = nil;
    
    [self.leftView removeFromSuperview];
    self.leftView = nil;
    [self.rightView removeFromSuperview];
    self.rightView = nil;
    [self.overlayerContentView removeFromSuperview];
    self.overlayerContentView = nil;
    
    [self.snapView removeFromSuperview];
    self.snapView = nil;
    
    self.selectionStyle = self.reallySelectionStyle;
}

#pragma mark - 手势 delegate
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer {
    if (gestureRecognizer == self.panGesture) {
        if (self.editing) {
            return NO;
        }
        self.highlighted = NO;
        CGPoint transion = [self.panGesture translationInView:self];
        return transion.y == 0;
    } else if (gestureRecognizer == self.tapGesture) {
        if (self.overlayerContentView) {
            return YES;
        } else {
            return NO;
        }
    }
    return YES;
}

#pragma mark - setter/getter
- (UITableView *)tableView {
    if (!_tableView) {
        UIView *nextView = self.superview;
        while (nextView) {
            if ([nextView isKindOfClass:[UITableView class]]) {
                _tableView = (UITableView *)nextView;
                break;
            }
            nextView = nextView.superview;
        }
    }
    return _tableView;
}

- (UITapGestureRecognizer *)tapGesture {
    if (!_tapGesture) {
        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGestureCallback:)];
        tapGesture.delegate = self;
        _tapGesture = tapGesture;
    }
    return _tapGesture;
}

- (void)tapGestureCallback:(UITapGestureRecognizer *)tapGesture {
    if (self.overlayerContentView) {
        if (self.panCellOperation == PanCellOperationOpenLeft) {
            [self animatedCloseLeft];
        } else {
            [self animatedCloseRight];
        }
    }
}

- (CGFloat)animatedTypePercent {
    if (self.animatedStyle == PanCellAnimatedStyleNone) {
        return 0.f;
    }
    else if (self.animatedStyle == PanCellAnimatedStyleParallax) {
        return 0.7f;
    }
    else {
        return 1.f;
    }
}

@end
