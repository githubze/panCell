//
//  PanCellMenuView.h
//  UITableView-侧滑
//
//  Created by juliu on 16/12/28.
//  Copyright © 2016年 juliu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PanCellButton.h"

@interface PanCellMenuView : UIView

- (instancetype)initWithPanCellButtons:(NSArray<PanCellButton *> *)buttons height:(CGFloat)height;

@end
