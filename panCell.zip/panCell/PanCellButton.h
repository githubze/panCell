//
//  PanCellButton.h
//  UITableView-侧滑
//
//  Created by juliu on 16/12/27.
//  Copyright © 2016年 juliu. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void(^PanCellButtonCallback)(UIButton *panButton);

@interface PanCellButton : UIButton

- (instancetype)initWithTitle:(NSString *)title image:(UIImage *)image onClickCallback:(PanCellButtonCallback)callback;

@end
