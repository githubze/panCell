//
//  PanCellMenuView.m
//  UITableView-侧滑
//
//  Created by juliu on 16/12/28.
//  Copyright © 2016年 juliu. All rights reserved.
//

#import "PanCellMenuView.h"

@interface PanCellMenuView ()

@end

@implementation PanCellMenuView

- (instancetype)initWithPanCellButtons:(NSArray<PanCellButton *> *)buttons height:(CGFloat)height {
    if (self = [super init]) {
        // 添加侧滑按钮，并设置侧滑按钮的frame与自己的frame
        CGFloat btnX = 0.f;
        CGFloat allBtnWidth = 0.f;
        for (PanCellButton *button in [buttons reverseObjectEnumerator]) {
            [self addSubview:button];
            
            button.frame = CGRectMake(btnX, 0, button.bounds.size.width, height);
            btnX += button.bounds.size.width;
            allBtnWidth += button.bounds.size.width;
        }
        self.frame = CGRectMake(0.f, 0.f, allBtnWidth, height);
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

@end
